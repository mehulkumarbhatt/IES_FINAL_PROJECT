using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Basics.Pages.RazorSecured
{
    public class Anon : PageModel
    {
        public void OnGet()
        {
            
        }
    }
}
 using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Basics.Pages.Razor
{
    public class Secured : PageModel
    {
        public void OnGet()
        {
            
        }
    }
}
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Basics.Pages.Razor
{
    public class Index : PageModel
    {
        public void OnGet()
        {
            
        }
    }
}
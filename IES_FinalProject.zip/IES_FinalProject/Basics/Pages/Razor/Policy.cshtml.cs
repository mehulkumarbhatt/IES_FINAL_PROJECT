using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Basics.Pages.Razor
{
    public class Policy : PageModel
    {
        public void OnGet()
        {
            
        }
    }
}